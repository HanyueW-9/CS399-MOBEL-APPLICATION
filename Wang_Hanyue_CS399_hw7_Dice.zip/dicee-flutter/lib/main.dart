import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  return runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.pink[100],
        appBar: AppBar(
          title: Text('Pink Dicee'),
          backgroundColor: Colors.pink[200],
        ),
        body: DicePage(),
      ),
    ),
  );
}

class DicePage extends StatefulWidget {
  @override
  _DicePageState createState() => _DicePageState();
}

class _DicePageState extends State<DicePage> {
  int DN1 = 1;
  int DN2 = 1;
  int DN3 = 1;
  int DN4 = 1;
  int DN5 = 1;

  void changeDN(){
    setState(() {
      DN1 = Random().nextInt(6) + 1;
      DN2 = Random().nextInt(6) + 1;
      DN3 = Random().nextInt(6) + 1;
      DN4 = Random().nextInt(6) + 1;
      DN5 = Random().nextInt(6) + 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        children: <Widget>[
          Expanded(
            child: FlatButton(
              onPressed: (){
                changeDN();
              },
              child: Image.asset('images/dice$DN1.png'),
            ),
          ),
          Expanded(
            child: FlatButton(
              onPressed: (){
                  changeDN();
              },
              child: Image.asset('images/dice$DN2.png'),
            ),
          ),
          Expanded(
            child: FlatButton(
              onPressed: (){
                changeDN();
              },
              child: Image.asset('images/dice$DN3.png'),
            ),
          ),
          Expanded(
            child: FlatButton(
              onPressed: (){
                changeDN();
              },
              child: Image.asset('images/dice$DN4.png'),
            ),
          ),
          Expanded(
            child: FlatButton(
              onPressed: (){
                changeDN();
              },
              child: Image.asset('images/dice$DN5.png'),
            ),
          ),
        ],
      ),
    );
  }
}
